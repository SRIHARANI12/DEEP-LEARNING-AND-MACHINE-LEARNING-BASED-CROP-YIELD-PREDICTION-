package com.mycompany.farmeradvisoryplatform

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
