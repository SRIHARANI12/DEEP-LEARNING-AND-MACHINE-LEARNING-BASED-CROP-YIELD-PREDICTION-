// Export pages
export '/dashboard1/dashboard1_widget.dart' show Dashboard1Widget;
export '/profile/profile_widget.dart' show ProfileWidget;
export '/auth2/auth2_widget.dart' show Auth2Widget;
export '/dash/dash_widget.dart' show DashWidget;
export '/future/future_widget.dart' show FutureWidget;
export '/profileedit/profileedit_widget.dart' show ProfileeditWidget;
