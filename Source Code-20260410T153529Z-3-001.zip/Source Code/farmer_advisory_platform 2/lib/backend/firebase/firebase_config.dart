import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDkkZSbpjLhT6dVpo17q6Th5mvj8hVbSjk",
            authDomain: "farmer-advisory-platfor-fg074x.firebaseapp.com",
            projectId: "farmer-advisory-platfor-fg074x",
            storageBucket: "farmer-advisory-platfor-fg074x.firebasestorage.app",
            messagingSenderId: "101778411762",
            appId: "1:101778411762:web:c13fdab054b4b398fec06b"));
  } else {
    await Firebase.initializeApp();
  }
}
