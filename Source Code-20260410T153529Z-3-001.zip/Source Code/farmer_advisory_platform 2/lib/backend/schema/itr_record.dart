import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ItrRecord extends FirestoreRecord {
  ItrRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "createdBY" field.
  String? _createdBY;
  String get createdBY => _createdBY ?? '';
  bool hasCreatedBY() => _createdBY != null;

  // "loc" field.
  LatLng? _loc;
  LatLng? get loc => _loc;
  bool hasLoc() => _loc != null;

  // "crop" field.
  String? _crop;
  String get crop => _crop ?? '';
  bool hasCrop() => _crop != null;

  // "plantenOn" field.
  String? _plantenOn;
  String get plantenOn => _plantenOn ?? '';
  bool hasPlantenOn() => _plantenOn != null;

  // "AiResponse" field.
  String? _aiResponse;
  String get aiResponse => _aiResponse ?? '';
  bool hasAiResponse() => _aiResponse != null;

  // "query" field.
  String? _query;
  String get query => _query ?? '';
  bool hasQuery() => _query != null;

  void _initializeFields() {
    _createdBY = snapshotData['createdBY'] as String?;
    _loc = snapshotData['loc'] as LatLng?;
    _crop = snapshotData['crop'] as String?;
    _plantenOn = snapshotData['plantenOn'] as String?;
    _aiResponse = snapshotData['AiResponse'] as String?;
    _query = snapshotData['query'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('itr');

  static Stream<ItrRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ItrRecord.fromSnapshot(s));

  static Future<ItrRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ItrRecord.fromSnapshot(s));

  static ItrRecord fromSnapshot(DocumentSnapshot snapshot) => ItrRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ItrRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ItrRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ItrRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ItrRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createItrRecordData({
  String? createdBY,
  LatLng? loc,
  String? crop,
  String? plantenOn,
  String? aiResponse,
  String? query,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'createdBY': createdBY,
      'loc': loc,
      'crop': crop,
      'plantenOn': plantenOn,
      'AiResponse': aiResponse,
      'query': query,
    }.withoutNulls,
  );

  return firestoreData;
}

class ItrRecordDocumentEquality implements Equality<ItrRecord> {
  const ItrRecordDocumentEquality();

  @override
  bool equals(ItrRecord? e1, ItrRecord? e2) {
    return e1?.createdBY == e2?.createdBY &&
        e1?.loc == e2?.loc &&
        e1?.crop == e2?.crop &&
        e1?.plantenOn == e2?.plantenOn &&
        e1?.aiResponse == e2?.aiResponse &&
        e1?.query == e2?.query;
  }

  @override
  int hash(ItrRecord? e) => const ListEquality().hash(
      [e?.createdBY, e?.loc, e?.crop, e?.plantenOn, e?.aiResponse, e?.query]);

  @override
  bool isValidKey(Object? o) => o is ItrRecord;
}
