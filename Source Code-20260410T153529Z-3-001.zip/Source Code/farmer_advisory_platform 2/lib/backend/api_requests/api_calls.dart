import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class GetWeatherCall {
  static Future<ApiCallResponse> call({
    double? lat,
    double? lon,
    String? appid = 'c5986ab5b66a27cc6779c8a004679c79',
    String? units = 'metric',
    String? exclude = 'minutely, hourly, alerts',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'getWeather',
      apiUrl: 'https://api.openweathermap.org/data/3.0/onecall',
      callType: ApiCallType.GET,
      headers: {
        'Content-type': 'application/json',
      },
      params: {
        'lat': lat,
        'lon': lon,
        'appid': appid,
        'units': units,
        'exclude': exclude,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SoilgetCall {
  static Future<ApiCallResponse> call({
    double? lat,
    double? lon,
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'soilget',
      apiUrl: 'https://rest.isric.org/soilgrids/v2.0/properties/query',
      callType: ApiCallType.GET,
      headers: {
        'Accept': 'application/Jjson',
      },
      params: {
        'lat': lat,
        'lon': lon,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class OpenAiCallCall {
  static Future<ApiCallResponse> call({
    String? q = '',
    String? wd = '',
    String? sd = '',
    String? p = '',
    String? m = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-4o",
  "messages": [
    {
      "role": "system",
      "content": "You are an agronomy assistant."
    },

    {
      "role": "user",
      "content": "Weather: {{wd}}${escapeStringForJson(wd)}, Soil: {{sd}}${escapeStringForJson(sd)}, and Query:${escapeStringForJson(q)} for Analyse , think harder and faster and give a solution for the crop:${escapeStringForJson(p)} on the month of:${escapeStringForJson(m)}."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'openAiCall',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: true,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? answer(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[0].message.content''',
      ));
}

class OpenAiCallFertilizerCall {
  static Future<ApiCallResponse> call({
    String? soilPlanted = '',
    String? wd = '',
    String? sd = '',
    String? latLong = '',
    String? month = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-4o",
  "messages": [
    {
      "role": "system",
      "content": "You are an agronomy assistant."
    },
    {
      "role": "user",
      "content": "Weather data: {{wd}}${escapeStringForJson(wd)}, Soil data: {{sd}}${escapeStringForJson(sd)}, and Crop planted:${escapeStringForJson(soilPlanted)} at the month of${escapeStringForJson(month)}. Also have the basic understanding of raining patterns of india accross the given coordinate${escapeStringForJson(latLong)} . give me data on yield and suggest some methods to increase yield in a brief"
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'openAiCallFertilizer',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: true,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? answer(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[0].message.content''',
      ));
}

class OpenAiCallWeatherCall {
  static Future<ApiCallResponse> call({
    String? wd = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-4o",
  "messages": [
    {
      "role": "system",
      "content": "You are an agronomy assistant."
    },
    {
      "role": "user",
      "content": "Weather: {{wd}}${escapeStringForJson(wd)},  Analyse and give a brief answer."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'openAiCallWeather',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: true,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? answer(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[0].message.content''',
      ));
}

class OpenAiCallSoilCall {
  static Future<ApiCallResponse> call({
    String? soil = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-4o",
  "messages": [
    {
      "role": "system",
      "content": "You are an agronomy assistant."
    },
    {
      "role": "user",
      "content": "Soil JSON: ${escapeStringForJson(soil)},  Analyse and give a brief answer on soil types and suggest crops to get better yield"
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'openAiCallSoil',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: true,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? answer(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[0].message.content''',
      ));
}

class OpenAiCallYieldPredictionCall {
  static Future<ApiCallResponse> call({
    String? soil = '',
    String? wea = '',
    String? loc = '',
    String? plant = '',
    String? mont = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-4o",
  "messages": [
    {
      "role": "system",
      "content": "You are an agronomy assistant."
    },
    {
      "role": "user",
      "content": "Predict the yield, and give some suggestions to increase the yield for the crop: ${escapeStringForJson(plant)} which was planted in the month of ${escapeStringForJson(mont)}. Also take the indian raining pattern at the location of Coimbator. also i have attached weather data ${escapeStringForJson(wea)} and soil data ${escapeStringForJson(soil)} Think harder and faster and give a shorter reply"
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'openAiCallYieldPrediction',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: true,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? answer(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[0].message.content''',
      ));
}

class OpenAiCalAiSuggestionCall {
  static Future<ApiCallResponse> call({
    String? soil = '',
    String? wea = '',
    String? loc = '',
    String? plant = '',
    String? mont = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-4o",
  "messages": [
    {
      "role": "system",
      "content": "You are an agronomy assistant."
    },
    {
      "role": "user",
      "content": "Predict the yield, Give some suggestion to improve the yield, and give some suggestions to increase the yield for the crop: ${escapeStringForJson(plant)} which was planted in the month of ${escapeStringForJson(mont)}. Also take the indian raining pattern at the location of ${escapeStringForJson(loc)} also i have attached weather data ${escapeStringForJson(wea)} and soil data ${escapeStringForJson(soil)} Think harder and faster and give a shorter reply for yield prediction and posible factors affecting yield and to increase the yield"
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'openAiCalAiSuggestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: true,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? answer(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[0].message.content''',
      ));
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
