// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

/// Set your action name, define your arguments and return parameter, and then
/// add the boilerplate code using the green button on the right!
Future<List<double>> extractLatLng(String latLngString) async {
  final lat = double.parse(latLngString.split("lat: ")[1].split(",")[0]);
  final lon = double.parse(latLngString.split("lng: ")[1].split(")")[0]);
  return [lat, lon];
}
