// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<List<double>> splitLatLong(String latLong) async {
  try {
    // Remove any whitespace and split by comma
    List<String> coordinates = latLong.trim().split(',');

    if (coordinates.length != 2) {
      throw FormatException(
          'Invalid lat/long format. Expected format: "lat,long"');
    }

    // Parse latitude and longitude
    double lat = double.parse(coordinates[0].trim());
    double lon = double.parse(coordinates[1].trim());

    // Validate coordinate ranges
    if (lat < -90 || lat > 90) {
      throw RangeError('Latitude must be between -90 and 90 degrees');
    }

    if (lon < -180 || lon > 180) {
      throw RangeError('Longitude must be between -180 and 180 degrees');
    }

    return [lat, lon];
  } catch (e) {
    // Return empty list or default coordinates in case of error
    return [0.0, 0.0];
  }
}
